<div class="row">
  <div class="col-md-12">
  	<h2><?= __('Car Rental Plugin - Calendar', 'carrental') ?></h2>
	</div>
</div>
